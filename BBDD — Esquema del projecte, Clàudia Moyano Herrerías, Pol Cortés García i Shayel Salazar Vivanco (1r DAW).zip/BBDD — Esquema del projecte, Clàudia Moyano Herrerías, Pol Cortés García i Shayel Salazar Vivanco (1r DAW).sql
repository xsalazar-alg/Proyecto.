CREATE TABLE player (
player_id VARCHAR(25) NOT NULL,
player_name VARCHAR(25) NOT NULL,
player_risk TINYINT,
PRIMARY KEY (player_id)
);

CREATE TABLE deck (
deck_id CHAR(3),
deck_name VARCHAR(25),
PRIMARY KEY (deck_id)
);

CREATE TABLE cardgame (
cardgame_id INT,
players TINYINT,
rounds TINYINT,
start_hour DATETIME,
end_hour DATETIME,
deck_id CHAR(3),
FOREIGN KEY (deck_id)
	REFERENCES deck(deck_id),
PRIMARY KEY (cardgame_id)
);

CREATE TABLE card (
card_id CHAR(3),
card_value DECIMAL(3,1),
card_priority TINYINT,
card_real_value TINYINT,
deck_id CHAR(3),
FOREIGN KEY (deck_id)
	REFERENCES deck(deck_id),
PRIMARY KEY (card_id)
);

CREATE TABLE player_game (
cardgame_id INT,
player_id VARCHAR(25),
initial_card_id CHAR(3),
starting_points TINYINT,
ending_points TINYINT,
FOREIGN KEY (cardgame_id)
	REFERENCES cardgame(cardgame_id),
FOREIGN KEY (player_id)
	REFERENCES player(player_id),
PRIMARY KEY(initial_card_id)
);

CREATE TABLE player_game_round (
cardgame_id INT,
round_num TINYINT,
player_id VARCHAR(25),
is_bank TINYINT(1),
bet_points TINYINT,
cards_value DECIMAL(4,1),
starting_round_points TINYINT,
ending_round_points TINYINT,
FOREIGN KEY (cardgame_id)
	REFERENCES cardgame(cardgame_id),
FOREIGN KEY (player_id)
	REFERENCES player(player_id),
PRIMARY KEY(round_num)
);