import os
import time

letraNIF = ["T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E"]

Players1 = "d8888b. d8888b. d8888b. d8888b.    d8888b. db       .d8b.  db    db d88888b d8888b. .d8888. "
Players2 = "88  `8D 88  `8D 88  `8D 88  `8D    88  `8D 88      d8' `8b `8b  d8' 88'     88  `8D 88'  YP "
Players3 = "88oooY' 88oooY' 88   88 88   88    88oodD' 88      88ooo88  `8bd8'  88ooooo 88oobY' `8bo.   "
Players4 = "88~~~b. 88~~~b. 88   88 88   88    88~~~   88      88~~~88    88    88~~~~~ 88`8b     `Y8b. "
Players5 = "88   8D 88   8D 88  .8D 88  .8D    88      88booo. 88   88    88    88.     88 `88. db   8D "
Players6 = "Y8888P' Y8888P' Y8888D' Y8888D'    88      Y88888P YP   YP    YP    Y88888P 88   YD `8888Y' "

lineas_titulo = "⊷" * 150

# ————————————————————————————————————————————————————————————————————— La idea es ponerlo antes de cada cambio de menú.
def borrarPantalla():
    try:
        if os.name == "ce" or os.name == "nt" or os.name == "dos":
            os.system("cls")
        elif os.name == "posix":
            os.system("clear")
        else:
            raise OSError
    except OSError:
        print("Your operating system couldn't be recognized, screen will not be cleaned.")


# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
def getOpt(textOpts="", inputOptText="", rangeList=[]):
    print(textOpts)
    inputOptText = input(" " * 63 + "Opció:\n" + " " * 63 + "> ")
    try:
        if inputOptText.isdigit():
            inputOptText = int(inputOptText)
        if inputOptText not in rangeList:
            raise IndexError
        if inputOptText in rangeList:
            return inputOptText
    except IndexError:
        input(" " * 49 + "This option is not valid. Press enter to continue...")
        borrarPantalla()


# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
def ChooseYourDeck(spanish1, spanish2, spanish3, spanish4, spanish5, spanish6, poker1, poker2, poker3, poker4, poker5,
                   poker6):
    opt_ok = False
    while not opt_ok:
        try:
            chooseSpanish = "Type \"Spanish\" and you will pick the spanish deck"
            print("\n\n", chooseSpanish.center(150))
            print(spanish1.center(151), '\n', spanish2.center(150), '\n', spanish3.center(150), "\n",
                  spanish4.center(150), '\n', spanish5.center(150), '\n', spanish6.center(150), "\n\n")
            # ------------------------------------
            choosePoker = "Type \"Poker\" and you will pick the poker deck"
            print("\n", choosePoker.center(150))
            print(poker1.center(151), "\n", poker2.center(150), "\n", poker3.center(150), "\n", poker4.center(150),
                  "\n", poker5.center(150), "\n", poker6.center(150), "\n\n")
            # ------------------------------------
            chooseBack = "Type \"Back\" to return"
            print(chooseBack.center(150))

            option = input("\n                                                              > ")
            option = option.lower()
            if option == "spanish" or option == "poker" or option == "back":
                return option
            else:
                raise TypeError

        except TypeError:
            print("That's not an option. Press ENTER to continue...")


# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
def maxRounds():
    rounds_ok = False
    while not rounds_ok:
        try:
            rounds = input("\n\n" + " " * 50 + "Select the max of rounds for the next game (5-30):\n" + " " * 50 + "> ")
            if not rounds.isdigit():
                raise TypeError
            rounds = int(rounds)
            if rounds < 5 or rounds > 30:
                raise ValueError
            else:
                rounds_ok = True
                return rounds
        except ValueError:
            print("\n" + " " * 50 + "That's not a valid number!")
            input(" " * 50 + "Press ENTER to continue...")
        except TypeError:
            print('\n' + " " * 50 + "That's not a number!")
            input(" " * 50 + "Press ENTER to continue...")


# —————————————————————————————————————————————————————————————————————————————————————— PRUEBAS.

def crear_nombre():
    borrarPantalla()
    print("\n", Players1.center(150), "\n", Players2.center(150), "\n", Players3.center(150), "\n", Players4.center(150),
          "\n", Players5.center(150), "\n", Players6.center(150), "\n")
    print(lineas_titulo.center(150))
    nombre_ok = False
    while not nombre_ok:
        try:
            nombre = input("Insert Name: ")
            if nombre.isspace() or nombre == "":
                raise TypeError("Incorrect typing")
            else:
                return nombre

        except TypeError:
            print("Space-only or empty names are not allowed. Type Name Again.")

def crear_dni():
    borrarPantalla()
    print("\n", Players1.center(150), "\n", Players2.center(150), "\n", Players3.center(150), "\n", Players4.center(150),
          "\n", Players5.center(150), "\n", Players6.center(150), "\n")
    print(lineas_titulo.center(150))
    dni_ok = False
    while not dni_ok:
        try:
            DNI = input("Insert NIF: ").upper()
            NIF = DNI[0:len(DNI)-1]
            if 9 > len(NIF) > 6:
                letraDNI = letraNIF[int(NIF) % 23]
                NIFadd = NIF + letraDNI
                if NIFadd == DNI:
                    return DNI
                else:
                    raise ValueError # Incorrect letter.
                
            else:
                raise IndexError # Incorrect length.
        
        except ValueError:
            print("The letter doesn't match with the NIF. Type NIF again.")

        except IndexError:
            print("NIF's length isn't correct. Type NIF again.")
                
def establecer_tipo():
    borrarPantalla()
    print("\n", Players1.center(150), "\n", Players2.center(150), "\n", Players3.center(150), "\n", Players4.center(150),
          "\n", Players5.center(150), "\n", Players6.center(150), "\n")
    print(lineas_titulo.center(150))
    opc = getOpt(textOpts="Select your profile:\n1) Cautious\n2) Moderated\n3) Bold", inputOptText="", rangeList=[1, 2, 3])
    if opc == 1:
        #son 30 puntos
        type = 30
        return type
    elif opc == 2:
        #son 40p
        type = 40
        return type
    elif opc == 3:
        #son 50p
        type = 50
        return type

def crear_jugador():
    nombre = crear_nombre()
    dni = crear_dni()
    type = establecer_tipo()
    return nombre, dni, type

def show_players_and_bots(myresult="", jugadores = {}, humans = {}, bots={}):
    for x in myresult:          # Los almacenamos a todos en un diccionario genérico
        player_id = x[0]
        player_name = x[1]
        player_risk = x[2]
        que_es = x[6]
        jugadores[player_id] = {'player_name':player_name, 'player_risk':player_risk, 'bot':que_es}

    for dni,datos_jugador in jugadores.items():         # Los separamos por humanos/bots
        if datos_jugador['bot'] == 0:
            humans[dni] = datos_jugador
        else:
            bots[dni] = datos_jugador
    
    contador_humanos = 0
    contador_bots = 0
    for dni in humans:
        contador_humanos += 1
    for dni in bots:
        contador_bots += 1
    
    if contador_humanos > contador_bots:
        veces_printear = contador_humanos
    elif contador_humanos<contador_bots:
        veces_printear = contador_bots
    elif contador_humanos == contador_bots:
        veces_printear = contador_humanos

    print1_bots = 0
    print2_bots = 1
    print3_bots = 2
    print1_humans = 0
    print2_humans = 1
    print3_humans = 2

    lista_bots = []
    lista_humans = []

    item_str =  "\n                                  "+"*"*34 +" Select Players " + "*"*34 + "\n" \
                "                                  ————————————————————————————————————————————————————————————————————————————————————\n" \
                "                                                   Bots                    ||                 Humans\n" \
                "                                  ————————————————————————————————————————————————————————————————————————————————————\n" \
                "                                   ID              Name              Type  ||  ID              Name              Type\n"\
                "                                  ————————————————————————————————————————————————————————————————————————————————————"

    for dni in bots:
        id_bots = dni
        name_bots = bots[dni]['player_name']
        type_bots = bots[dni]['player_risk']
        type_bots = str(type_bots)
        lista_bots.append(id_bots)
        lista_bots.append(name_bots)
        lista_bots.append(type_bots)

    for dni in humans:
        id_humans = dni
        name_humans = humans[dni]['player_name']
        type_humans = humans[dni]['player_risk']
        type_humans = str(type_humans)
        lista_humans.append(id_humans)
        lista_humans.append(name_humans)
        lista_humans.append(type_humans)

    len_humans  = len(lista_humans)
    len_bots    = len(lista_bots)

    if len_humans > len_bots:
        for i in range(len_bots, len_humans):
            lista_bots.append(' ')
    elif len_humans < len_bots:
        for i in range(len_humans, len_bots):
            lista_humans.append(' ')
    print(item_str)
    item_str2 = "                                   " + lista_bots[print1_bots].ljust(13) +'   '+ lista_bots[print2_bots].ljust(15) +'   '+ lista_bots[print3_bots].ljust(6) + "||  " + \
                lista_humans[print1_humans].ljust(13) +'   '+ lista_humans[print2_humans].ljust(15) +'   '+ lista_humans[print3_humans].ljust(6)
    for prints in range(len(lista_humans)):
        print(item_str2)
        if print3_bots != len(lista_bots)-1:
            print1_bots += 3                             
            print2_bots += 3                             
            print3_bots += 3                             
            print1_humans += 3                             
            print2_humans += 3                             
            print3_humans += 3                             
            item_str2 = "                                   " + lista_bots[print1_bots].ljust(13) +'   '+ lista_bots[print2_bots].ljust(15) +'   '+ lista_bots[print3_bots].ljust(6) + "||  " + \
                    lista_humans[print1_humans].ljust(13) +'   '+ lista_humans[print2_humans].ljust(15) +'   '+ lista_humans[print3_humans].ljust(6)
        else:
            break

def remove_players_or_bots(jugadores = ""):
    opc_ok = False
    while not opc_ok:
        opc = input("\n                                                      Option ( -id to remove player, -1 to exit ):\n                                                      > ")
        if len(opc) != 10:
            if opc == "-1":
                return "-1"
            else:
                input('Your answer isn\'t correct. Please, press "ENTER" to continue...')
        else:
            while opc[1:9].isdigit() and opc[9].isalpha() and opc[:1] == '-':
                opc[9] = opc[9].upper()
                opc_sure = input("Are you sure you want to delete the selected profile? Y/y = Yes or N/n = No")
                if opc_sure.lower() == "y":
                    return "y", opc
                elif opc_sure.lower() == "n":
                    return "n", opc
                else:
                    input("Incorrect option. Press \"ENTER\" to continue...")
            else:
                input('Your answer isn\'t correct. Please, press "ENTER" to continue...')

def is_empty(data_structure):       # Sirve para comprobar si un diccionario, lista...... está vacío o no.
    if data_structure:
        return False
    else:
        return True

def show_current_playing_players(jugadores = {}, lista_de_mientras=[], players_playing = {}):
    if not is_empty(players_playing):
        for dni in players_playing:
            id_humans = dni
            name_humans = jugadores[dni]['player_name']
            type_humans = jugadores[dni]['player_risk']
            type_humans = str(type_humans)
            lista_de_mientras.append(id_humans)
            lista_de_mientras.append(name_humans)
            lista_de_mientras.append(type_humans)
        print(      "                                                                    Actual Players in Game   \n" \
                    "                                  ————————————————————————————————————————————————————————————————————————————————————")
        print1 = 0
        print2 = 1
        print3 = 2
        print("                                   " + lista_de_mientras[print1].ljust(13) +'   '+ lista_de_mientras[print2].ljust(15) +'   '+ lista_de_mientras[print3].ljust(6))
        for prints in range(len(lista_de_mientras)):
            if print3 != len(lista_de_mientras)-1:
                print1 += 3
                print2 += 3
                print3 += 3
                print("                                   " + lista_de_mientras[print1].ljust(13) +'   '+ lista_de_mientras[print2].ljust(15) +'   '+ lista_de_mientras[print3].ljust(6))
    elif is_empty(players_playing):
        print(      "                                                                    Actual Players in Game   \n" \
                    "                                  ————————————————————————————————————————————————————————————————————————————————————\n")
        print(      "                                                                          Empty list!")
    input('Press ENTER to continue...')

def set_game_players(players_playing = '', jugadores = {}):
    opc = input("Option (id to add to game, -id to remove player, sh to show actual players in game, -1 to go back):\n")
    if len(opc) != 9:
        if opc == "-1":
            return "-1"
        elif not opc.isdigit():
            if opc.lower() == "sh":
                show_current_playing_players(players_playing=players_playing)
            else:
                input('Your answer isn\'t correct. Please, press "ENTER" to continue...')
        elif opc[1:9].isdigit() and opc[9].isalpha() and opc[:1] == '-':
            opc_ok = False
            while not opc_ok:
                opc_sure = input("Are you sure you want to delete the selected profile? Y/y = Yes or N/n = No")
                if opc_sure.lower() == "y":
                    return "y", opc
                elif opc_sure.lower() == "n":
                    return "n"
                else:
                    input("Incorrect option. Press \"ENTER\" to continue...")
        else:
            input('Your answer isn\'t correct. Please, press "ENTER" to continue...')
    else:
        if len(opc) == 9 and opc[:8].isdigit() and opc[8].isalpha():
            opc = opc.upper()
            if opc in players_playing:
                print('The selected player is already on the list')
            if opc in jugadores:
                for jugador,datos in jugadores.items():
                    if jugador == opc:
                        players_playing[jugador] = datos
                return players_playing
        else:
            input('Your answer isn\'t correct. Please, press "ENTER" to continue...')

'''
t0 = time.time()
input("Holaaaaa dale a ENTER para continuar...")
t1 = time.time()
tiempo_jugado = t1-t0
tiempo_jugado = round(tiempo_jugado)
minutos_jugados = tiempo_jugado / 60
print(t0, "\n", t1)
input(f"Has tardado {tiempo_jugado} segundos en darle al ENTER, y en minutos {minutos_jugados}.")
'''