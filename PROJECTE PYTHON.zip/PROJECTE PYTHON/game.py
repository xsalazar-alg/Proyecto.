# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
# —————————————————————————————————————————————————— COSAS QUE HACER ———————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————

#    - SET GAME PLAYERS     <---- LO PRIMERO AL LLEGAR A CLLASE!!!
#    - PLAY GAME
#    - NEW PLAYER/BOT --> QUE NO PETE AL PONER UN DNI YA EXISTENTE EN LA BBDD!!!!!!!
#    - MIRAR PROBLEMA AL BORRAR JUGADORES: PUEDE SER QUE NO SE REFRESQUE LA LISTA HASTA QUE NO SE REINICIE EL PROGRAMA!!!
#    - RÀNQUING
#    - REPORTS (2, 3, 6, 7, 8, 9 y 10)  <---- Cosillas de SQL a tope


# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
# —————————————————————————————————————————————————————— IMPORTS ———————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————

import mysql.connector

mydb = mysql.connector.connect(
    host="proyecto-claudia-shayel-pol.mysql.database.azure.com",
    user="pol@proyecto-claudia-shayel-pol",
    password="P@ssw0rd",
    database="set i mig"
)

mycursor = mydb.cursor()

import time
import random
import os
from functions import getOpt, borrarPantalla, ChooseYourDeck, maxRounds, crear_nombre, crear_dni, establecer_tipo, crear_jugador, show_players_and_bots, remove_players_or_bots, set_game_players, show_current_playing_players

# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————— TÍTOLS ———————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
lineas_titulo = "⊷" * 150

# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————— SEVEN AND HALF ———————————————————————————————————————————————————
# ————————————————————————— https://www.askapache.com/online-tools/figlet-ascii/ | FONT = basic ————————————————————————
# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————

Seven1 = " .d8888. d88888b db    db d88888b d8b   db "
Seven2 = " 88'  YP 88'     88    88 88'     888o  88 "
Seven3 = " `8bo.   88ooooo Y8    8P 88ooooo 88V8o 88 "
Seven4 = "   `Y8b. 88      `8b  d8' 88      88 V8o88 "
Seven5 = " db   8D 88.      `8bd8'  88.     88  V888 "
Seven6 = " `8888Y' Y88888P    YP    Y88888P VP   V8P "

And1 = "  .d8b.  d8b   db d8888b. "
And2 = " d8' `8b 888o  88 88  `8D "
And3 = " 88ooo88 88V8o 88 88   88 "
And4 = " 88   88 88 V8o88 88   88 "
And5 = " 88   88 88  V888 88  .8D "
And6 = " YP   YP VP   V8P Y8888D' "

Half1 = "db   db  .d8b.  db      d88888b "
Half2 = "88   88 d8' `8b 88      88'     "
Half3 = "88ooo88 88ooo88 88      88ooo   "
Half4 = "88   88 88   88 88      88      "
Half5 = "88   88 88   88 88booo. 88      "
Half6 = "YP   YP YP   YP Y88888P YP      "

BBDDPlayers1 = "d8888b. d8888b. d8888b. d8888b.    d8888b. db       .d8b.  db    db d88888b d8888b. .d8888. "
BBDDPlayers2 = "88  `8D 88  `8D 88  `8D 88  `8D    88  `8D 88      d8' `8b `8b  d8' 88'     88  `8D 88'  YP "
BBDDPlayers3 = "88oooY' 88oooY' 88   88 88   88    88oodD' 88      88ooo88  `8bd8'  88ooooo 88oobY' `8bo.   "
BBDDPlayers4 = "88  `b. 88  `b. 88   88 88   88    88      88      88   88    88    88      88`8b     `Y8b. "
BBDDPlayers5 = "88   8D 88   8D 88  .8D 88  .8D    88      88booo. 88   88    88    88.     88 `88. db   8D "
BBDDPlayers6 = "Y8888P' Y8888P' Y8888D' Y8888D'    88      Y88888P YP   YP    YP    Y88888P 88   YD `8888Y' "

settings1 = ".d8888. d88888b d888888b d888888b d888888b d8b   db  d888b  .d8888. "
settings2 = "88'  YP 88'        88       88      `88'   888o  88 88' Y8b 88'  YP "
settings3 = "`8bo.   88ooooo    88       88       88    88V8o 88 88      `8bo.   "
settings4 = "  `Y8b. 88         88       88       88    88 V8o88 88  roo   `Y8b. "
settings5 = "db   8D 88.        88       88      .88.   88  V888 88. 88  db   8D "
settings6 = "`8888Y' Y88888P    YP       YP    Y888888P VP   V8P  Y888P  `8888Y' "

show1 = ".d8888. db   db  .d88b.  db   d8b   db    d8888b. d88888b .88b  d88.  .d88b.  db    db d88888b "
show2 = "88'  YP 88   88 .8P  Y8. 88   I8I   88    88  `8D 88'     88'YbdP`88 .8P  Y8. 88    88 88'     "
show3 = "`8bo.   88ooo88 88    88 88   I8I   88    88oobY' 88ooooo 88  88  88 88    88 Y8    8P 88ooooo "
show4 = "  `Y8b. 88   88 88    88 Y8   I8I   88    88`8b   88      88  88  88 88    88 `8b  d8' 88      "
show5 = "db   8D 88   88 `8b  d8' `8b d8'8b d8'    88 `88. 88.     88  88  88 `8b  d8'  `8bd8'  88.     "
show6 = "`8888Y' YP   YP  `Y88P'   `8b8' `8d8'     88   YD Y88888P YP  YP  YP  `Y88P'     YP    Y88888P "

players1 = "d8888b. db       .d8b.  db    db d88888b d8888b. .d8888. "
players2 = "88  `8D 88      d8' `8b `8b  d8' 88'     88  `8D 88'  YP "
players3 = "88oodD' 88      88ooo88  `8bd8'  88ooooo 88oobY' `8bo.   "
players4 = "88      88      88   88    88    88      88`8b     `Y8b. "
players5 = "88      88booo. 88   88    88    88.     88 `88. db   8D "
players6 = "88      Y88888P YP   YP    YP    Y88888P 88   YD `8888Y' "

setPlayers1 = ".d8888. d88888b d888888b     d888b   .d8b.  .88b  d88. d88888b    d8888b. db       .d8b.  db    db d88888b d8888b. .d8888. "
setPlayers2 = "88'  YP 88'        88       88' Y8b d8' `8b 88'YbdP`88 88'        88  `8D 88      d8' `8b `8b  d8' 88'     88  `8D 88'  YP "
setPlayers3 = "`8bo.   88ooooo    88       88      88ooo88 88  88  88 88ooooo    88oodD' 88      88ooo88  `8bd8'  88ooooo 88oobY' `8bo.   "
setPlayers4 = "  `Y8b. 88'        88       88  roo 88   88 88  88  88 88         88      88      88   88    88    88      88`8b     `Y8b. "
setPlayers5 = "db   8D 88.        88       88. 88  88   88 88  88  88 88.        88      88booo. 88   88    88    88.     88 `88. db   8D "
setPlayers6 = "`8888Y' Y88888P    YP        Y888P  YP   YP YP  YP  YP Y88888P    88      Y88888P YP   YP    YP    Y88888P 88   YD `8888Y' "

pick1 = "d8888b. d888888b  .o88b. db   dD        .d8b.        d8888b. d88888b  .o88b. db   dD "
pick2 = "88  `8D   `88'   d8P  Y8 88 ,8P'       d8' `8b       88  `8D 88'     d8P  Y8 88 ,8P' "
pick3 = "88oodD'    88    8P      88,8P         88ooo88       88   88 88ooooo 8P      88,8P   "
pick4 = "88         88    8b      88`8b         88   88       88   88 88      8b      88`8b   "
pick5 = "88        .88.   Y8b  d8 88 `88.       88   88       88  .8D 88.     Y8b  88 88 `88. "
pick6 = "88      Y888888P  `Y88P' YP   YD       YP   YP       Y8888D' Y88888P  `Y88P' YP   YD "

set1 = ".d8888. d88888b d888888b     .88b  d88.  .d8b.  db    db "
set2 = "88'  YP 88'        88        88'YbdP`88 d8' `8b `8b  d8' "
set3 = "`8bo.   88ooooo    88        88  88  88 88ooo88  `8bd8'  "
set4 = "  `Y8b. 88         88        88  88  88 88   88  .dPYb.  "
set5 = "db   8D 88.        88        88  88  88 88   88 .8P  Y8. "
set6 = "`8888Y' Y88888P    YP        YP  YP  YP YP   YP YP    YP "

rounds1 = "d8888b.  .d88b.  db    db d8b   db d8888b. .d8888."
rounds2 = "88  `8D .8P  Y8. 88    88 888o  88 88  `8D 88'  YP "
rounds3 = "88oobY' 88    88 88    88 88V8o 88 88   88 `8bo.   "
rounds4 = "88`8b   88    88 88    88 88 V8o88 88   88   `Y8b. "
rounds5 = "88 `88. `8b  d8' 88b  d88 88  V888 88  .8D db   8D "
rounds6 = "88   YD  `Y88P'  ~Y8888P' VP   V8P Y8888D' `8888Y' "

nrounds1 = ",d88888        d8888b.  .d88b.  "
nrounds2 = "88             VP  `8D .8P  88. "
nrounds3 = "dP88b.           oooY' 88  d'88 "
nrounds4 = "    b88 C8888D   ~~~b. 88 d' 88 "
nrounds5 = "    `8D        db   8D `88  d8' "
nrounds6 = "88oobY'        Y8888P'  `Y88P'  "

spanish1 = ".------..------..------..------..------..------..------."
spanish2 = "|S.--. ||P.--. ||A.--. ||N.--. ||I.--. ||S.--. ||H.--. |"
spanish3 = "| :/\: || :/\: || (\/) || :(): || (\/) || :/\: || :/\: |"
spanish4 = "| :\/: || (__) || :\/: || ()() || :\/: || :\/: || (__) |"
spanish5 = "| '--'S|| '--'P|| '--'A|| '--'N|| '--'I|| '--'S|| '--'H|"
spanish6 = "`------'`------'`------'`------'`------'`------'`------'"

poker1 = ".------..------..------..------..------."
poker2 = "|P.--. ||O.--. ||K.--. ||E.--. ||R.--. |"
poker3 = "| :/\: || :/\: || :/\: || (\/) || :(): |"
poker4 = "| (__) || :\/: || :\/: || :\/: || ()() |"
poker5 = "| '--'P|| '--'O|| '--'K|| '--'E|| '--'R|"
poker6 = "`------'`------'`------'`------'`------'"

letraNIF = ["T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E"]


# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————— MENÚS ————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————

menu00 = "\n" + " " * 63 + "1) Add/Remove/Show Players".ljust(60) + "\n" + " " * 63 + \
         "2) Settings".ljust(60) + "\n" + " " * 63 + \
         "3) Play Game".ljust(60) + "\n" + " " * 63 + \
         "4) Ranking".ljust(60) + "\n" + " " * 63 + \
         "5) Reports".ljust(60) + "\n" + " " * 63 + \
         "6) Exit".ljust(60)

menu01 = "\n" + " " * 63 + "1) New Human Player".ljust(60) + "\n" + " " * 63 + \
         "2) New Boot".ljust(60) + "\n" + " " * 63 + \
         "3) Show/Remove Players".ljust(60) + "\n" + " " * 63 + \
         "4) Go Back".ljust(60)

menu02 = "\n" + " " * 63 + "1) Set Game Players".ljust(60) + "\n" + " " * 63 + \
         "2) Set Card's Deck (Default Spanish Deck)".ljust(60) + "\n" + " " * 63 + \
         "3) Set Max Rounds (Default 5 Rounds)".ljust(60) + "\n" + " " * 63 + \
         "4) Go Back".ljust(60)

menu04 = "\n" + " " * 63 + "1) Players With More Earnings".ljust(60) + "\n" + " " * 63 + \
         "2) Players With More Games Played".ljust(60) + "\n" + " " * 63 + \
         "3) Players With More Minutes Played".ljust(60)

menu05 = "\n" + " " * 63 + \
         "1) Initial card more repeated by each user,\nonly users who have played a minimum of 3 games".ljust(60) + \
         "\n" + " " * 63 + \
         "2) Player who makes the highest bet per game,\nfind the round with the highest bet".ljust(60) + \
         "\n" + " " * 63 + "3) Player who makes the lowest bet per game".ljust(60) + "\n" + " " * 63 + \
         "4) Percentage of rounds won per player in each game\n(%), as well as their average bet for the " \
         "game".ljust(60) + "\n" + " " * 63 + "5) List of games won by Bots".ljust(60) + "\n" + " " * 63 + \
         "6) Rounds won by the bank in each game".ljust(60) + "\n" + " " * 63 + \
         "7) Number of users have been the bank in each game".ljust(60) + "\n" + " " * 63 + \
         "8) Average bet per game".ljust(60) + "\n" + " " * 63 + \
         "9) Average bet of the first round of each game".ljust(60) + "\n" + " " * 63 + \
         "10) Average bet of the last round of each game".ljust(60) + "\n" + " " * 63 + \
         "11) Go Back"

# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
# —————————————————————————————————————————————————————— BARAJAS ———————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————

baraja_de_mientras = {}

# BARAJA ESPAÑOLA

mycursor.execute("SELECT * FROM card WHERE deck_id = 1 ORDER BY card_id asc")
myresult = mycursor.fetchall()

for x in myresult:          # Los almacenamos a todos en un diccionario genérico
    card_id = x[0]
    card_value = x[1]
    card_priority = x[2]
    card_real_value = x[3]
    deck_id = x [4]
    card_name = x[5]
    baraja_de_mientras[card_id] = {'card_value':card_value, 'card_priority':card_priority, 'card_real_value':card_real_value, 'deck_id':deck_id, 'card_name':card_name}

baraja_española = baraja_de_mientras

# BARAJA DE POKER

mycursor.execute("SELECT * FROM card WHERE deck_id = 2 ORDER BY card_id asc")
myresult = mycursor.fetchall()

for x in myresult:          # Los almacenamos a todos en un diccionario genérico
    card_id = x[0]
    card_value = x[1]
    card_priority = x[2]
    card_real_value = x[3]
    deck_id = x [4]
    card_name = x[5]
    baraja_de_mientras[card_id] = {'card_value':card_value, 'card_priority':card_priority, 'card_real_value':card_real_value, 'deck_id':deck_id, 'card_name':card_name}

baraja_poker = baraja_de_mientras

# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
# —————————————————————————————————————————————————— VARIABLES VARIAS ——————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————

baraja = baraja_española
players_playing = {}
opc = None


# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————— JUEGO ————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————————————————————————————————————————————

while opc != -1:
    # ————————————————————————————————————————————————————————————————————————————————————————————————————————— MENÚ 00.
    while opc is None:
        print("\n", Seven1.center(150), "\n", Seven2.center(150), "\n", Seven3.center(150), "\n", Seven4.center(150),
              "\n", Seven5.center(150), "\n", Seven6.center(150))
        print("\n", And1.center(150), "\n", And2.center(150), "\n", And3.center(150), "\n", And4.center(150), "\n",
              And5.center(150), "\n", And6.center(150))
        print("\n", Half1.center(150), "\n", Half2.center(150), "\n", Half3.center(150), "\n", Half4.center(150), "\n",
              Half5.center(150), "\n", Half6.center(150), "\n")
        print(lineas_titulo.center(150))
        opc = getOpt(textOpts=menu00, inputOptText="", rangeList=[1, 2, 3, 4, 5, 6])

    # ————————————————————————————————————————————————————————————————————————————————————————————————————————— MENÚ 01.
    while opc == 1:
        borrarPantalla()
        print("\n", BBDDPlayers1.center(150), "\n", BBDDPlayers2.center(150), "\n", BBDDPlayers3.center(150), "\n", BBDDPlayers4.center(150),
              "\n", BBDDPlayers5.center(150), "\n", BBDDPlayers6.center(150), "\n")
        print(lineas_titulo.center(150))
        opc1 = getOpt(textOpts=menu01, inputOptText="", rangeList=[1, 2, 3, 4])

        # ————————————————————————————————————————————————————————————————————————————————————————————————————————— CREATE HUMAN.
        if opc1 == 1:
            new_name, new_dni, new_type = crear_jugador()
            sql = "INSERT INTO player (player_id, player_name, player_risk, games_played, total_points_earned, total_minutes_played, bot, human) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
            val = (new_dni, new_name, new_type, 0, 0, 0, 0, 1)
            mycursor.execute(sql, val)
            mydb.commit()
                                # mysql.connector.errors.IntegrityError  <-- Para si pones un dni ya existente en la lista!!

        # ————————————————————————————————————————————————————————————————————————————————————————————————————————— CREATE BOT.
        if opc1 == 2:
            new_name, new_dni, new_type = crear_jugador()
            sql = "INSERT INTO player (player_id, player_name, player_risk, games_played, total_points_earned, total_minutes_played, bot, human) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
            val = (new_dni, new_name, new_type, 0, 0, 0, 1, 0)
            mycursor.execute(sql, val)
            mydb.commit()

        # ————————————————————————————————————————————————————————————————————————————————————————————————————————— SHOW/REMOVE PLAYERS.
        if opc1 == 3:
            que_hacer = ''
        
            borrarPantalla()
            print("\n", show1.center(150), '\n', show2.center(150), '\n', show3.center(150), '\n',
            show4.center(150), '\n', show5.center(150), '\n', show6.center(150))
            print("\n", players1.center(150), '\n', players2.center(150), '\n', players3.center(150), '\n',
            players4.center(150), '\n', players5.center(150), '\n', players6.center(150))
            print("\n", lineas_titulo.center(150), "\n")
            mycursor.execute("SELECT * FROM player")
            myresult = mycursor.fetchall()              # Hacemos llamada de los players de la base de datos

            print(show_players_and_bots(myresult=myresult))

            jugadores = {}
            
            for x in myresult:          # Los almacenamos a todos en un diccionario genérico
                player_id = x[0]
                player_name = x[1]
                player_risk = x[2]
                que_es = x[6]
                jugadores[player_id] = {'player_name':player_name, 'player_risk':player_risk, 'bot':que_es}

            que_hacer, dni_borrar = remove_players_or_bots(jugadores = jugadores)
            if que_hacer == "y":
                sql = "DELETE FROM player WHERE player_id = %s"
                adr = (dni_borrar[1:], )
                mycursor.execute(sql, adr)
                mydb.commit()
                input('Player deleted succesfully. Press "ENTER" to continue...')
            elif que_hacer == "n":
                pass
            elif que_hacer == "-1":
                opc1 = None
                opc = None

        if opc1 == 4:           # Go back
            borrarPantalla()
            opc1 = None
            opc = None

    # ————————————————————————————————————————————————————————————————————————————————————————————————————————— SETTINGS.
    while opc == 2:
        borrarPantalla()
        print("\n", settings1.center(150), '\n', settings2.center(150), '\n', settings3.center(150), '\n',
              settings4.center(150), '\n', settings5.center(150), '\n', settings6.center(150))
        print("\n", lineas_titulo.center(150), "\n")
        opc2 = getOpt(textOpts=menu02, inputOptText="", rangeList=[1, 2, 3, 4])
        borrarPantalla()

        # ————————————————————————————————————————————————————————————————————————————————————————————————— SET GAME PLAYERS.
        if opc2 == 1:
            exit_ok = False
            while not exit_ok:
                borrarPantalla()
                print("\n", setPlayers1.center(150), "\n", setPlayers2.center(150), "\n", setPlayers3.center(150), "\n", setPlayers4.center(150),
                    "\n", setPlayers5.center(150), "\n", setPlayers6.center(150), "\n")
                print(lineas_titulo.center(150))
                mycursor.execute("SELECT * FROM player")
                myresult = mycursor.fetchall()
                
                jugadores = {}

                for x in myresult:          # Los almacenamos a todos en un diccionario genérico
                    player_id = x[0]
                    player_name = x[1]
                    player_risk = x[2]
                    que_es = x[6]
                    jugadores[player_id] = {'player_name':player_name, 'player_risk':player_risk, 'bot':que_es}

                # ANTES DE LA FUNCIÓN, TIENE QUE HABER AQUÍ UN PRINT DE LA LISTA DE LOS PLAYERS PICKEADOS ANTERIORMENTE
                
                print(show_players_and_bots(myresult=myresult))     # IMPRIMIMOS LA LISTA DE PERSONAS/BOTS QUE HAY EN LA BBDD ACTUALMENTE
                
                cosa_obtenida = set_game_players(players_playing = players_playing, jugadores = jugadores)     # AQUI LA FUNCION() DE PONER QUE PLAYERS/BOTS JUGARÁN.
                if cosa_obtenida == "-1":
                    exit_ok = True
                if isinstance(cosa_obtenida, dict):
                    players_playing = cosa_obtenida
                show_current_playing_players(players_playing = cosa_obtenida, jugadores=jugadores)
                borrarPantalla()
            opc2 = None

        # ————————————————————————————————————————————————————————————————————————————————————————————————— PICK A DECK.
        elif opc2 == 2:
            borrarPantalla()
            print("\n", pick1.center(150), '\n', pick2.center(150), '\n', pick3.center(150), '\n', pick4.center(150),
                  '\n', pick5.center(150), '\n', pick6.center(150))
            print("\n", lineas_titulo.center(150))
            opc_baraja = ChooseYourDeck(spanish1, spanish2, spanish3, spanish4, spanish5, spanish6, poker1, poker2,
                                        poker3, poker4, poker5, poker6)
            if opc_baraja == "spanish":
                baraja = baraja_española
                print("\n" + " " * 55 + "Your deck have been changed successfully")
                input(" " * 65 + "Press enter to continue...")
            elif opc_baraja == "poker":
                baraja = baraja_poker
                print("\n" + " " * 55 + "Your deck have been changed successfully")
                input(" " * 65 + "Press enter to continue...")
            borrarPantalla()

        # —————————————————————————————————————————————————————————————————————————————————————————————— SET MAX ROUNDS.
        elif opc2 == 3:
            print("\n", set1.center(150), "\n", set2.center(150), "\n", set3.center(150), "\n", set4.center(150), '\n',
                  set5.center(150), "\n", set6.center(150))
            print("\n", rounds1.center(148), "\n", rounds2.center(150), "\n", rounds3.center(150), "\n",
                  rounds4.center(150), "\n", rounds5.center(150), "\n", rounds6.center(150))
            print("\n", lineas_titulo.center(150))
            print("\n", nrounds1.center(150), "\n", nrounds2.center(150), "\n", nrounds3.center(150), "\n",
                  nrounds4.center(150), "\n", nrounds5.center(150), "\n", nrounds6.center(150))
            rounds = maxRounds()
            print(" " * 50 + "Max of rounds setted succesfully!")
            input(" " * 50 + "Press enter to continue...")
            borrarPantalla()

        # ————————————————————————————————————————————————————————————————————————————————————————————————————— GO BACK.
        elif opc2 == 4:
            borrarPantalla()
            opc2 = None
            opc = None

    # ————————————————————————————————————————————————————————————————————————————————————————————————————————— PLAY GAME.
    if opc == 3:
        if len(players_playing) >= 2:
            print('Set the players that compose the game first (atleast 2)')
        elif len(players_playing) < 7 and len(players_playing) > 1:
            print('Aquí va el juego')
            mycursor.execute("SELECT * FROM player_game")
            myresult = mycursor.fetchall()
            

        input("ENTER to continue...")

    # ————————————————————————————————————————————————————————————————————————————————————————————————————————— RANKING.
    if opc == 4:
        print("Aquest és el rànquing.")
        input("Press enter to continue...")

    # ————————————————————————————————————————————————————————————————————————————————————————————————————————— REPORTS.
    if opc == 5:
        print("Reports. Queremos hacer al menos 2, 3, 6, 7, 8, 9 y 10.")
        input("Press enter to continue...")

    # ————————————————————————————————————————————————————————————————————————————————————————————————————————— GO BACK.
    if opc == 6:
        opc = -1